finance package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   finance.src
   finance.tests

Module contents
---------------

.. automodule:: finance
   :members:
   :undoc-members:
   :show-inheritance:
